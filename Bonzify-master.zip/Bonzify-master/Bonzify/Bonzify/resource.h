//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Bonzify.rc

#define IDR_BONZICHAR                   100
#define IDR_AGENTINSTALLER              101
#define IDR_TRUVOICEINSTALLER           102
#define IDR_KILLAGENT                   103
#define IDR_TAKEOWN                     104

#define IDR_HOOKDLL                     110
