# Bonzify

**READ THIS BEFORE YOU SUBMIT AN ISSUE**

Source Code will be coming soon™, because I have to improve the rushed code a lot, add disclaimers and stuff...
