# Illuminati Joke Program

A joke program that scans the screen for triangles and overlays them with the Illuminati logo while playing the X-Files theme.

It uses OpenCV for recognizing the triangles. The AI is OK, but sometimes generates false-positives or does not recognize a triangle at all. I'm trying to do my best in order to get "perfect" results.

It currently only works for the active window and only on the main screen. It also needs a lot of CPU power and does not work on XP or lower.
