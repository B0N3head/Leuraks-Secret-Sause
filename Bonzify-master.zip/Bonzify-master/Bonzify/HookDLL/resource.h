//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HookDLL.rc

#define IDI_BONZI                       1
#define IDS_BONZI                       1
