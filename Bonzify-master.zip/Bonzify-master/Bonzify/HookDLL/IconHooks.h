#include "Hook.h"

extern HOOK LoadIconW_Hook;
extern HOOK LoadImageW_Hook;
extern HOOK ExtractIconExW_Hook;
extern HOOK PrivateExtractIconsW_Hook;
extern HOOK ExtractAssociatedIconW_Hook;