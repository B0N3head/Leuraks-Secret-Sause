#include <Windows.h>

void Bonzi_Init();
void Bonzi_Speak(LPWSTR message);